"""Experimental positional plans for positive relational joins.

This is an interpreter specialization, not an implementation of RPT+ or a
worst-case-optimal join algorithm. Exact bucket selection remains dynamic;
variable classification is compiled once and intermediate bindings use slots.
"""
from .model import EQ, NEQ, Var


class RelationalPlan:
    __slots__ = ("variables", "atoms")

    def __init__(self, rule):
        variables = {}
        atoms = []
        for atom in rule.body:
            terms = []
            for term in atom.args:
                if isinstance(term, Var):
                    terms.append((variables.setdefault(term, len(variables)), None))
                else:
                    terms.append((-1, term))
            atoms.append((atom.predicate, tuple(terms)))
        self.variables = tuple(variables)
        self.atoms = tuple(atoms)

    @classmethod
    def create(cls, rule):
        if not rule.body or any(atom.predicate in {EQ, NEQ} for atom in rule.body):
            return None
        return cls(rule)

    def solutions(self, engine, missing, delta_index=None, delta_position=None, initial=None):
        """Yield the same complete bindings as the generic positive evaluator."""
        initial = {} if initial is None else initial
        variables = self.variables
        # Constants can change representatives after equality ingestion, so only
        # their positions are cached. Resolve values anew on every invocation.
        atoms = tuple((predicate, tuple(slot for slot, _ in terms),
                       tuple(engine.normalize(term) if slot < 0 else missing
                             for slot, term in terms),
                       delta_index if position == delta_position else engine._index)
                      for position, (predicate, terms) in enumerate(self.atoms))
        stats = engine.stats

        def visit(remaining, binding):
            if not remaining:
                stats["body_matches"] += 1
                yield {**initial, **dict(zip(variables, binding))}
                return
            chosen = None
            size = float("inf")
            for position in remaining:
                predicate, slots, constants, relation = atoms[position]
                values = tuple(binding[slot] if slot >= 0 else constant
                               for slot, constant in zip(slots, constants))
                rows = relation.lookup(predicate, values)
                count = len(rows)
                if count == 0:
                    return
                if count < size:
                    chosen = position, slots, values, rows
                    size = count
            position, slots, values, rows = chosen
            rest = tuple(p for p in remaining if p != position)
            for row in rows:
                stats["candidate_rows"] += 1
                extended = binding.copy()
                for slot, actual, expected in zip(slots, row, values):
                    if slot >= 0:
                        bound = extended[slot]
                        if bound is not missing and bound != actual:
                            break
                        extended[slot] = actual
                    elif actual != expected:
                        break
                else:
                    yield from visit(rest, extended)

        yield from visit(tuple(range(len(atoms))),
                         [initial.get(variable, missing) for variable in variables])
